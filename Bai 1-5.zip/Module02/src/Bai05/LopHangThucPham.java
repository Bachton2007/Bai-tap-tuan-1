package Bai05;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.DecimalFormat;

public class LopHangThucPham {
    private String maHang;
    private String tenHang;
    private double donGia;
    private LocalDate ngaySanXuat;
    private LocalDate ngayHetHan;

    private void setMaHang(String maHang) throws Exception {
        if (maHang != null && !maHang.trim().equals("")) {
            this.maHang = maHang;
        } else {
            throw new Exception("Lỗi: Mã hàng rỗng!");
        }
    }

    public LopHangThucPham(String maHang) throws Exception {
        setMaHang(maHang);
        this.tenHang = "xxx";
        this.donGia = 0;
        this.ngaySanXuat = LocalDate.now();
        this.ngayHetHan = this.ngaySanXuat;
    }

    public LopHangThucPham(String maHang, String tenHang, double donGia, LocalDate ngaySanXuat, LocalDate ngayHetHan) throws Exception {
        setMaHang(maHang);
        setTenHang(tenHang);
        setDonGia(donGia);
        setNgaySanXuat(ngaySanXuat);
        setNgayHetHan(ngayHetHan);
    }

    public String getMaHang() { return maHang; }

    public String getTenHang() { return tenHang; }
    
    public void setTenHang(String tenHang) {
        if (tenHang != null && !tenHang.trim().isEmpty()) {
            this.tenHang = tenHang;
        } else {
            this.tenHang = "xxx";
        }
    }

    public double getDonGia() { return donGia; }
    
    public void setDonGia(double donGia) {
        if (donGia >= 0) {
            this.donGia = donGia;
        } else {
            this.donGia = 0;
        }
    }

    public LocalDate getNgaySanXuat() { return ngaySanXuat; }
    
    public void setNgaySanXuat(LocalDate ngaySanXuat) {
        if (ngaySanXuat != null && !ngaySanXuat.isAfter(LocalDate.now())) {
            this.ngaySanXuat = ngaySanXuat;
        } else {
            this.ngaySanXuat = LocalDate.now();
        }
    }

    public LocalDate getNgayHetHan() { return ngayHetHan; }
    
    public void setNgayHetHan(LocalDate ngayHetHan) {
        if (ngayHetHan != null && !ngayHetHan.isBefore(this.ngaySanXuat)) {
            this.ngayHetHan = ngayHetHan;
        } else {
            this.ngayHetHan = this.ngaySanXuat;
        }
    }

    public boolean hetHan() {
        return ngayHetHan.isBefore(LocalDate.now());
    }

    public String toString() {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String ghiChu = hetHan() ? "Hàng hết hạn" : "";
        
        return String.format("%-15s %-9s %10sVND %13s %16s      %-20s",
                maHang, tenHang, df.format(donGia),
                dtf.format(ngaySanXuat), dtf.format(ngayHetHan), ghiChu);
    }
}