package Bai05;
import java.time.LocalDate;

public class Main {

	public static void main(String[] args) {
		try {
			LopHangThucPham htp1 = new LopHangThucPham(
					"001",
					"Gạo",
					100000,
					LocalDate.of(2018, 7, 10),
					LocalDate.of(2018, 3, 1)
				);
			
			LopHangThucPham htp2 = new LopHangThucPham(
					"002",
					"Mì",
					5000,
					LocalDate.of(2018, 3, 1),
					LocalDate.of(2018, 9, 1)
				);
			
			LopHangThucPham htp3 = new LopHangThucPham(
					"003",
					"Nước",
					10000,
					LocalDate.of(2017, 3, 1),
					LocalDate.of(2018, 3, 1)
				);
			
			System.out.printf("%-13s %-4s %13s %17s %16s       %-18s\n",
					"Mã_Hàng", "Tên_Hàng", "Đơn_Giá", "Ngày_Sản_Xuất", "Ngày_Hết_Hạn", "Ghi_Chú");
			
			System.out.println("---------------------------------------------------------------------------------------------");
            System.out.println(htp1);
            System.out.println(htp2);
            System.out.println(htp3);

        } catch (Exception e) {
            System.out.println(e.getMessage());
		}

	}

}
