package Bai01;

public class LopToaDo {
	private double x;
    private double y;
    private String tenToaDo;

    public LopToaDo() {
        this.x = 0;
        this.y = 0;
        this.tenToaDo = "";
    }
    
    public LopToaDo(double x, double y, String tenToaDo) {
        this.x = x;
        this.y = y;
        this.tenToaDo = tenToaDo;
    }
    
    public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public String getTenToaDo() {
		return tenToaDo;
	}

	public void setTenToaDo(String tenToaDo) {
		this.tenToaDo = tenToaDo;
	}
	
    public String toString() {
        return tenToaDo + "(" + x + ", " + y + ")";
    }
}

