package Bai01;

	public class Main {
	    public static void main(String[] args) {
	        LopToaDo td1 = new LopToaDo();
	        td1.setTenToaDo("A");
	        td1.setX(2.5);
	        td1.setY(4.0);

	        LopToaDo td2 = new LopToaDo(5.0, 7.2, "B");
	        System.out.println("--- KẾT QUẢ KIỂM NGHIỆM ---");
	        System.out.println("Tọa độ điểm 1: " + td1.toString());
	        System.out.println("Tọa độ điểm 2: " + td2);
	        System.out.println("\nThông tin chi tiết điểm 2:");
	        System.out.println("Tên: " + td2.getTenToaDo());
	        System.out.println("Hoành độ x: " + td2.getX());
	        System.out.println("Tung độ y: " + td2.getY());
	    }
	}
