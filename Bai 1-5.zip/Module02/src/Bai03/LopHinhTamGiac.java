package Bai03;

public class LopHinhTamGiac {
    private double ma;
    private double mb;
    private double mc;

    private boolean laTamGiac(double a, double b, double c) {
        return (a > 0 && b > 0 && c > 0) && (a + b > c) && (a + c > b) && (b + c > a);
    }

    public LopHinhTamGiac() {
        this.ma = 0;
        this.mb = 0;
        this.mc = 0;
    }

    public LopHinhTamGiac(double ma, double mb, double mc) {
        if (laTamGiac(ma, mb, mc)) {
            this.ma = ma;
            this.mb = mb;
            this.mc = mc;
        } else {
            this.ma = 0;
            this.mb = 0;
            this.mc = 0;
        }
    }

    public double getMa() {
        return ma;
    }

    public void setMa(double ma) {
        if (laTamGiac(ma, this.mb, this.mc)) {
            this.ma = ma;
        }
    }

    public double getMb() {
        return mb;
    }

    public void setMb(double mb) {
        if (laTamGiac(this.ma, mb, this.mc)) {
            this.mb = mb;
        }
    }

    public double getMc() {
        return mc;
    }

    public void setMc(double mc) {
        if (laTamGiac(this.ma, this.mb, mc)) {
            this.mc = mc;
        }
    }

    public double tinhChuVi() {
        if (!laTamGiac(ma, mb, mc)) {
            return 0;
        }
        return ma + mb + mc;
    }

    public double tinhDienTich() {
        if (!laTamGiac(ma, mb, mc)) {
            return 0;
        }
        double p = tinhChuVi() / 2.0;
        return Math.sqrt(p * (p - ma) * (p - mb) * (p - mc));
    }

    public String getKieuTamGiac() {
        if (!laTamGiac(ma, mb, mc)) {
            return "Không phải tam giác";
        }
        if (ma == mb && mb == mc) {
            return "Tam giác đều";
        }
        if (ma == mb || ma == mc || mb == mc) {
            return "Tam giác cân";
        }
        return "Tam giác thường";
    }

    public String toString() {
        return String.format("%-10.2f %-10.2f %-10.2f %-25s %-12.2f %-12.2f",
                ma, mb, mc, getKieuTamGiac(), tinhChuVi(), tinhDienTich());
    }
}