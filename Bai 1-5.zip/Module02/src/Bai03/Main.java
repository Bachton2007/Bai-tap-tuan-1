package Bai03;

public class Main {
    public static void main(String[] args) {

        LopHinhTamGiac tg1 = new LopHinhTamGiac(-3, 4, 5);      
        LopHinhTamGiac tg2 = new LopHinhTamGiac(1, 2, 5);
        LopHinhTamGiac tg3 = new LopHinhTamGiac(6, 6, 6);       
        LopHinhTamGiac tg4 = new LopHinhTamGiac(5, 5, 8);      
        LopHinhTamGiac tg5 = new LopHinhTamGiac(3, 4, 5);       

        System.out.printf("%-10s %-10s %-10s %-25s %-12s %-12s\n", 
                "Cạnh a", "Cạnh b", "Cạnh c", "Kiểu tam giác", "Chu vi", "Diện tích");
        System.out.println("----------------------------------------------------------------------------------");
        System.out.println(tg1);
        System.out.println(tg2);
        System.out.println(tg3);
        System.out.println(tg4);
        System.out.println(tg5);
    }
}