package Bai04;

public class Main {
    public static void main(String[] args) {

        LopVehicle xe1 = new LopVehicle("Nguyễn Thu Loan", "Future Neo", 35000000.0, 100);
        LopVehicle xe2 = new LopVehicle("Lê Minh Tính", "Ford Ranger", 250000000.0, 3000);
        LopVehicle xe3 = new LopVehicle("Nguyễn Minh Triết", "Landscape", 1000000000.0, 1500);

        System.out.printf("%-20s %-20s %10s %18s %22s\n", 
                "Tên chủ xe", "Loại xe", "Dung tích", "Trị giá", "Thuế phải nộp");

        System.out.println("===============================================================================================");

        System.out.println(xe1);
        System.out.println(xe2);
        System.out.println(xe3);
    }
}