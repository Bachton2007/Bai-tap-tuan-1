package Bai04;

public class LopVehicle {
	
    private String chuXe;
    private String loaiXe;
    private double triGia;
    private int dungTich;

    public LopVehicle() {
        this.chuXe = "Chưa có tên";
        this.loaiXe = "Chưa xác định";
        this.triGia = 0;
        this.dungTich = 0;
    }

    public LopVehicle(String chuXe, String loaiXe, double triGia, int dungTich) {
        setChuXe(chuXe);
        setLoaiXe(loaiXe);
        setTriGia(triGia);
        setDungTich(dungTich);
    }

    public String getChuXe() {
        return chuXe;
    }

    public void setChuXe(String chuXe) {
        if (chuXe != null && !chuXe.trim().isEmpty()) {
            this.chuXe = chuXe;
        } else {
            this.chuXe = "Chưa có tên";
        }
    }

    public String getLoaiXe() {
        return loaiXe;
    }

    public void setLoaiXe(String loaiXe) {
        if (loaiXe != null && !loaiXe.trim().isEmpty()) {
            this.loaiXe = loaiXe;
        } else {
            this.loaiXe = "Chưa xác định";
        }
    }

    public double getTriGia() {
        return triGia;
    }

    public void setTriGia(double triGia) {
        if (triGia >= 0) {
            this.triGia = triGia;
        } else {
            this.triGia = 0;
        }
    }

    public int getDungTich() {
        return dungTich;
    }

    public void setDungTich(int dungTich) {
        if (dungTich >= 0) {
            this.dungTich = dungTich;
        } else {
            this.dungTich = 0;
        }
    }

    public double tinhThue() {
        if (dungTich < 100) {
            return triGia * 0.01;
        } else if (dungTich <= 200) {
            return triGia * 0.03;
        } else {
            return triGia * 0.05;
        }
    }

    public String toString() {
        return String.format("%-20s %-20s %10d %20.2f %18.2f", 
                chuXe, loaiXe, dungTich, triGia, tinhThue());
    }
}