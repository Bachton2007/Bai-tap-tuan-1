package Bai02;

public class LopSinhVien {

    private int maSV;
    private String hoTen;
    private float diemLT;
    private float diemTH;

    public LopSinhVien() {
        this.maSV = 0;
        this.hoTen = "";
        this.diemLT = 0.0f;
        this.diemTH = 0.0f;
    }

    public LopSinhVien(int maSV, String hoTen, float diemLT, float diemTH) {
        setMaSV(maSV);
        setHoTen(hoTen);
        setDiemLT(diemLT);
        setDiemTH(diemTH);
    }

    public int getMaSV() {
        return maSV;
    }

    public void setMaSV(int maSV) {
        if (maSV > 0) {
            this.maSV = maSV;
        } else {
            this.maSV = 0;
        }
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        if (hoTen != null && !hoTen.trim().isEmpty()) {
            this.hoTen = hoTen;
        } else {
            this.hoTen = "";
        }
    }

    public float getDiemLT() {
        return diemLT;
    }

    public void setDiemLT(float diemLT) {
        if (diemLT >= 0.0f && diemLT <= 10.0f) {
            this.diemLT = diemLT;
        } else {
            this.diemLT = 0.0f;
        }
    }

    public float getDiemTH() {
        return diemTH;
    }

    public void setDiemTH(float diemTH) {
        if (diemTH >= 0.0f && diemTH <= 10.0f) {
            this.diemTH = diemTH;
        } else {
            this.diemTH = 0.0f;
        }
    }

    public float tinhDiemTB() {
        return (this.diemLT + this.diemTH) / 2;
    }

    public String toString() {
        return String.format("%-7d %-30s %10.2f %10.2f %10.2f", 
                maSV, hoTen, diemLT, diemTH, tinhDiemTB());
    }
}