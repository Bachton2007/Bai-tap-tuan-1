package Bai02;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        LopSinhVien sv1 = new LopSinhVien(25738035, "Nguyễn Văn Kính", 6.50f, 8.00f);

        LopSinhVien sv2 = new LopSinhVien(25739081, "Phan Hữu Minh", 9.50f, 2.00f);

        System.out.println("Nhập mã số của sinh viên sv3:");
        int maSV3 = Integer.parseInt(scanner.nextLine());

        System.out.println("Nhập họ và tên của sinh viên sv3:");
        String hoTen3 = scanner.nextLine();

        System.out.println("Nhập điểm lý thuyết của sinh viên sv3:");
        float diemLT3 = Float.parseFloat(scanner.nextLine());

        System.out.println("Nhập điểm thực hành của sinh viên sv3:");
        float diemTH3 = Float.parseFloat(scanner.nextLine());

        LopSinhVien sv3 = new LopSinhVien();
        sv3.setMaSV(maSV3);
        sv3.setHoTen(hoTen3);
        sv3.setDiemLT(diemLT3);
        sv3.setDiemTH(diemTH3);

        System.out.println(String.format("%-7s %-30s %10s %10s %10s", 
                "masv", "hoten", "diemlt", "diemth", "diemtb"));

        System.out.println(sv1);
        System.out.println(sv2);
        System.out.println(sv3);

        scanner.close();
    }
}